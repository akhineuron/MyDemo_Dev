//
//  ViewController.m
//  AnimationTutorial
//
//  Created by Neuron Mac on 20/06/15.
//  Copyright (c) 2015 Neuron Mac. All rights reserved.
//

#import "ViewController.h"
#import "PagedImageScrollView.h"

@interface ViewController ()<UICollectionViewDataSource>
{
    NSArray *collectionImages;
    UIImageView *originalImageView;
    UIImageView *fullScreenImageView;
    UITapGestureRecognizer *gesture;

}

@property (nonatomic) UIDynamicAnimator *animator;
@property (weak, nonatomic) IBOutlet PagedImageScrollView *popup;
@property (weak, nonatomic) IBOutlet UICollectionView *collectionView;
@property (weak, nonatomic) IBOutlet UIButton *btnCart;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
     collectionImages = [NSArray arrayWithObjects:@"image1.png",@"image2.png",@"image3.png",@"image4.png",@"image5.png",@"image6.png",@"image7.png",@"image8.png",@"image9.png",@"image10.png",@"image11.png", nil];
    
    _popup.hidden       = YES;
    
    
    
    gesture  = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(ImageTapped)];
    gesture.numberOfTapsRequired    = 1;
    gesture.numberOfTouchesRequired = 1;
    [self.collectionView addGestureRecognizer:gesture];
    
    //Reload collection data
   
    _popup.delegate     = self;
    [_popup setScrollViewContents:collectionImages];
    [self.collectionView reloadData];
    // Do any additional setup after loading the view, typically from a nib.
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return collectionImages.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier = @"cellIdentifier";
    
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:identifier forIndexPath:indexPath];
    
    UIImageView *collectionImageView = (UIImageView *)[cell viewWithTag:100];
    collectionImageView.image        = [UIImage imageNamed:[collectionImages objectAtIndex:indexPath.row]];
    
    return cell;
}
-(void)ImageTapped
{
    CGPoint pointInCollectionView      = [gesture locationInView:self.collectionView];
    NSIndexPath *selectedIndexPath     = [self.collectionView indexPathForItemAtPoint:pointInCollectionView];
    UICollectionViewCell *selectedCell = [self.collectionView cellForItemAtIndexPath:selectedIndexPath];
    
    
    CGPoint scrollOffset    = CGPointMake(0, selectedIndexPath.row * (_popup.frame.size.height-40));

    // contentSize has now been changed
    [_popup.scrollView setContentOffset:scrollOffset animated:NO];
   
    _popup.pageControl.currentPage = selectedIndexPath.row;
    
    
    
    originalImageView = (UIImageView *)[selectedCell viewWithTag:100]; // or whatever cell element holds your image that you want to zoom
    
    fullScreenImageView = [[UIImageView alloc] init];
    [fullScreenImageView setContentMode:UIViewContentModeScaleToFill];
    
    fullScreenImageView.image = [originalImageView image];
    // ***********************************************************************************
    // You can either use this to zoom in from the center of your cell
    CGRect tempPoint = CGRectMake(originalImageView.center.x, originalImageView.center.y, 0, 0);
    // OR, if you want to zoom from the tapped point...
    //CGRect tempPoint = CGRectMake(pointInCollectionView.x, pointInCollectionView.y, 0, 0);
    // ***********************************************************************************
    CGRect startingPoint = [self.view convertRect:tempPoint fromView:[self.collectionView cellForItemAtIndexPath:selectedIndexPath]];
    [fullScreenImageView setFrame:startingPoint];
    [fullScreenImageView setBackgroundColor:[[UIColor lightGrayColor] colorWithAlphaComponent:0.9f]];
    
    [self.view addSubview:fullScreenImageView];
    
 [UIView animateWithDuration:0.9
                                       animations:^{
                                           [fullScreenImageView setFrame:CGRectMake(0,
                                                                                    0,
                                                                                    self.view.bounds.size.width,
                                                                                    self.view.bounds.size.height-40)];
                                       } completion:^(BOOL finished) {
                                           
                                           
                                           _popup.hidden = NO;
                                           fullScreenImageView.hidden = YES;

                                           CATransition *transition    = [CATransition animation];
                                           transition.duration         = 1.9f;
                                           transition.timingFunction   = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
                                           transition.type = kCATransitionFade;
                                           
                                           [fullScreenImageView.layer addAnimation:transition forKey:nil];

                                           transition.duration = 0.5f;
                                           [_popup.layer addAnimation:transition forKey:nil];


   
 }];

    
    
    
                         
                    
  
    
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(fullScreenImageViewTapped:)];
    
    singleTap.numberOfTapsRequired    = 1;
    singleTap.numberOfTouchesRequired = 1;
    
    [fullScreenImageView addGestureRecognizer:singleTap];
    [fullScreenImageView setUserInteractionEnabled:YES];

}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell * cell = (UICollectionViewCell *)[collectionView cellForItemAtIndexPath:indexPath];
    
    CGPoint pointInCollectionView = cell.center;
    
    //[self animatePopu_1: cell: indexPath.item];
    
   
    
    
    
}
- (void)fullScreenImageViewTapped:(UIGestureRecognizer *)gestureRecognizer {
    
    CGRect point=[self.view convertRect:originalImageView.bounds fromView:originalImageView];
    gestureRecognizer.view.backgroundColor=[UIColor clearColor];
    
    [UIView animateWithDuration:0.5
                     animations:^{
                         [(UIImageView *)gestureRecognizer.view setFrame:point];
                     }];
    [self performSelector:@selector(animationDone:) withObject:[gestureRecognizer view] afterDelay:0.4];
}

-(void)animationDone:(UIView  *)view
{
    [fullScreenImageView removeFromSuperview];
    fullScreenImageView = nil;
}
- (void) animatePopUpShow
{
    _popup.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.0, 0.0);
    
    [UIView animateWithDuration:0.5 animations:^{
        _popup.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.3 animations:^{
            _popup.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.99, 0.99);
        } completion:^(BOOL finished) {
            
        }];
    }];
}
- (void) animatePopu_1 : (UICollectionViewCell *) myView : (int) pos
{
   
        CGPoint scrollOffset    = CGPointMake(0,pos * _popup.frame.size.height);
    
    
    for (UIView *i in _popup.subviews){
        if(![i isKindOfClass:[UIButton class]])
        {
            [i removeFromSuperview];
        }
    }
    
    PagedImageScrollView *pageScroller = [[PagedImageScrollView alloc] initWithFrame:CGRectMake(0, 0, _popup.frame.size.width, _popup.frame.size.height-40)];
    pageScroller.delegate     = self;
    [pageScroller setScrollViewContents:collectionImages];
    
        // contentSize has now been changed
    [pageScroller.scrollView setContentOffset:scrollOffset animated:NO];
    [_popup addSubview:pageScroller];
    pageScroller.pageControl.currentPage = pos;
    
    UIImageView *collectionImageView = (UIImageView *)[myView viewWithTag:100];
    
    UIImageView *imgview = [[UIImageView alloc] initWithImage:collectionImageView.image];
    CGRect frame         = imgview.frame;
    frame.origin.x       = 0;
    frame.origin.y       = 0;
    frame.size.height    = _popup.frame.size.height-40;
    frame.size.width     = _popup.frame.size.width;
    
    imgview.frame        = frame;
    
    //imageview
    CGRect oldFrame1     = imgview.frame;
    CGPoint oldCenter1   = myView.center;
    
    //popu view
    CGRect oldFrame     = _popup.frame;
    CGPoint oldCenter   = myView.center;
    
    _popup.frame = CGRectZero;
    _popup.center = oldCenter;
    
    imgview.frame = CGRectZero;
    imgview.center = oldCenter1;
    
    _popup.hidden = NO;
    
    NSTimeInterval duration = 0.7;
    
    [UIView animateWithDuration:duration delay:0.0 options:UIViewAnimationOptionAllowUserInteraction animations:^{
        // New position and size after the animation should be the same as in Interface Builder
        //[_popup imageOpen:pos : myView.center];
        _popup.frame = oldFrame;
        //imgview.frame = oldFrame;
        //[_popup addSubview:imgview];
       
    }
     completion:^(BOOL finished){

         // You can do some stuff here after the animation finished
     }];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)btnDone_Action:(id)sender
{
    _popup.hidden = YES;
}
@end
