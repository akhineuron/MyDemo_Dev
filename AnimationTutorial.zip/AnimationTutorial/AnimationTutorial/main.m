//
//  main.m
//  AnimationTutorial
//
//  Created by Neuron Mac on 20/06/15.
//  Copyright (c) 2015 Neuron Mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
